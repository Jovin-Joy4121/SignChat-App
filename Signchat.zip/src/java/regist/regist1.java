

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package regist;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class regist1 {
    
    public Connection cn=null;
    public regist1()
    {
        try {      
            Class.forName("com.mysql.jdbc.Driver");
            cn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/signlog","root","");
        } catch (SQLException ex) {
            Logger.getLogger(regist1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(regist1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public boolean execution(PreparedStatement ps) throws SQLException
    {
        boolean result=false;
        result=ps.execute();
        return result;
    }
    public ResultSet return_data(PreparedStatement ps) throws SQLException
    {
        ResultSet rs=null;
        rs=ps.executeQuery();
        return rs;
    }
}